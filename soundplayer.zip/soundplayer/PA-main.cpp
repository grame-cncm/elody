/* link with  */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <errno.h>
#include <time.h>
#include <direct.h>
#include <fcntl.h>
#include <sys/types.h>
#include <assert.h>
#include <list>
#include <vector>
#include <MidiShare.h>

#include <iostream>
#include <fstream>

#include <libgen.h>
#include "portaudio.h"
#include "sampler.h"

#define OUTPUT_DEVICE Pa_GetDefaultOutputDevice()
#define SAMPLE_RATE   (44100)
#define FRAMES_PER_BUFFER  (1024)

typedef struct
{
	float *outCompute[8];
    int numOutputs;
}
paUserData;

using namespace std;


/******************************************************************************
 *******************************************************************************

								 FAUST DSP

 *******************************************************************************
 *******************************************************************************/


//----------------------------------------------------------------
//  definition du processeur de signal
//----------------------------------------------------------------

class dsp
{
	protected:
		int fSamplingFreq;
	public:
		dsp() {}
		virtual int getNumInputs() 										= 0;
		virtual int getNumOutputs() 									= 0;
		virtual void init(int samplingRate) 							= 0;
		virtual void compute(int len, float** inputs, float** outputs) 	= 0;
		virtual void conclude()											= 0;
};


//----------------------------------------------------------------------------
// 	FAUST generated code
//----------------------------------------------------------------------------

class soundplayer
{
	int			fNumOutputs;
	TSampler 	fSampler;
	int 		fRefnum;

	public:
	soundplayer() : fNumOutputs(8) {}
	virtual ~soundplayer() {}

	virtual int getNumInputs()
	{
		return 0;
	}
	virtual int getNumOutputs() 	
	{
	   	return fNumOutputs;
   	}
	virtual void setNumOutputs(int n) 	
	{
	   fNumOutputs=n;
   	}
	virtual void init(char* soundConfigFile, int samplingRate)
   	{
		initSampler(&fSampler, soundConfigFile);
		fSampler.fStereoMode = (fNumOutputs==2) ;
		if (fSampler.fStereoMode)
			printf("Mode stereo\n");
		else
			printf("Mode 8 pistes\n");
		fRefnum = MidiOpen("soundplayer");
		MidiConnect(0,fRefnum,1);
		MidiSetInfo(fRefnum, &fSampler);
		//MidiSetRcvAlarm(fRefnum, processMidiEvents);
	}

	virtual void compute(int len, float** inputs, float** outputs)
	{
		for (int c=0; c<fNumOutputs; c++)
	   	{
			for (int i=0; i<len; i++)
			   	outputs[c][i] = 0.0;
		}
		processMidiEvents(fRefnum);
		mixAllVoices (&fSampler, len, outputs);

		// post processing for volume control
		const float v = fSampler.fMaster;
		for (int d=0; c<fNumOutputs; d++)
	   	{
			float* out = outputs[d];
			for (int i=0; i<len; i++)
			  	out[i] *= v;
		}
	}

	virtual void conclude()
	{	
		MidiClose(fRefnum);
	}

};


soundplayer	DSP;


/******************************************************************************
 *******************************************************************************

							 PORTAUDIO INTERFACE

 *******************************************************************************
 *******************************************************************************/



//----------------------------------------------------------------------------
// 	number of input and output channels
//----------------------------------------------------------------------------

int		gNumOutChans;


//----------------------------------------------------------------------------
// file name used to store and recall the state of the application
//----------------------------------------------------------------------------

char	soundConfName[256];

//-- command line arguments

bool	gHelpSwitch 	= false;
bool	gVersionSwitch 	= false;
bool	gDetailsSwitch 	= false;

char*	gAudioConfigFile = 0;


//----------------------------------------------------------------------------
// PortAudio Callback
//----------------------------------------------------------------------------

int process (const void *inputBuffer, void *outputBuffer,
		unsigned long framesPerBuffer, const PaStreamCallbackTimeInfo* timeInfo,
		PaStreamCallbackFlags statusFlags, void *userData)
{
	int i, j;
	(void) inputBuffer;	/* Prevent "unused variable" warnings. */ 
	(void) timeInfo; 
	(void) statusFlags;	

	paUserData *data = (paUserData*)userData;

	DSP.compute(framesPerBuffer, NULL, data->outCompute);

	// uninterlacing loop
	float *out = (float*)outputBuffer;
	for (i=0; i<framesPerBuffer; i++)
	{
		for (j=0; j<data->numOutputs; j++)
		{
			*out++ = data->outCompute[j][i];
		}
	}
	return 0;
}


/******************************************************************************
 *******************************************************************************

							 MAIN PLAY THREAD

 *******************************************************************************
 *******************************************************************************/


bool check_file(char* filename)
{
	FILE* f = fopen(filename, "r");

	if (f == NULL) 
	{
		fprintf(stderr, "soundplayer: "); perror(filename);
	}
	else
	{
		fclose(f);
	}
	return f != NULL;
}


/****************************************************************
  Command line tools and arguments
 *****************************************************************/


//-- command line tools

static bool isCmd(char* cmd, char* kw1)
{
	return 	(strcmp(cmd, kw1) == 0);
}	

static bool isCmd(char* cmd, char* kw1, char* kw2)
{
	return 	(strcmp(cmd, kw1) == 0) || (strcmp(cmd, kw2) == 0);
}	

bool process_cmdline(int argc, char* argv[])
{
	int	i=1; int err=0;

	while (i<argc)
	{

		if (isCmd(argv[i], "-h", "--help")) 
		{
			gHelpSwitch = true;
			i += 1;

		}
		else
			if (isCmd(argv[i], "-v", "--version")) 
			{
				gVersionSwitch = true;
				i += 1;

			}
			else
				if (isCmd(argv[i], "-d", "--details"))
				{
					gDetailsSwitch = true;
					i += 1;

				}
				else
					if (argv[i][0] != '-')
					{
						if (check_file(argv[i]))
						{
							gAudioConfigFile = argv[i];
						}
						i++;

					}
					else
					{
						cerr << "soundplayer: unrecognized option \""
							<< argv[i] <<"\"" << endl;
						i++;
						err++;
					}
	}

	return err == 0;	
}



/****************************************************************
  Help and Version information
 *****************************************************************/



void printversion()
{
	cout << "SOUND PLAYER, MIDI controled Soundfile player, Version 1.0a\n";
	cout << "Copyright (C) 2003-2004, GRAME - Centre National de Creation Musicale. All rights reserved. \n\n";
}	


void printhelp()
{
	printversion();
	cout << "usage: soundplayer [-h|--help] [-v|--version] [<config file>]\n";

	cout << "\noptions :\n";
	cout << "---------\n";

	cout << "-h or --help\t\tprint this help message\n";
	cout << "-v or --version\t\tprint version\n";


	cout << "\nexample :\n";
	cout << "---------\n";

	cout << "soundplayer mySoundConf\n";
}



//-------------------------------------------------------------------------
// 									MAIN
//-------------------------------------------------------------------------

int main(int argc, char *argv[] )
{
	PaStream *stream;
	PaError err;
	const PaDeviceInfo* devInfo;
	
	PaStreamParameters outputParameters;

	char c;
	int i;

	/*---------------------------------------------------------------
	  1 - Process command line
	  ----------------------------------------------------------------*/

	process_cmdline(argc, argv);

	if (gHelpSwitch)
	{
		printhelp();
		exit(0);
	}
	if (gVersionSwitch) 
	{
		printversion();
		exit(0);
	}	

	/*---------------------------------------------------------------
	  2 - Initialize PortAudio & Open audio stream
	  ----------------------------------------------------------------*/

	err = Pa_Initialize();
	if ( err != paNoError )
		goto error;

	devInfo = Pa_GetDeviceInfo( OUTPUT_DEVICE );
	gNumOutChans = devInfo->maxOutputChannels;
	DSP.setNumOutputs(gNumOutChans);
	
	paUserData data;
	data.numOutputs = gNumOutChans;
	for (i=0; i<gNumOutChans; i++)
	{
 		data.outCompute[i] = (float*) calloc(FRAMES_PER_BUFFER,sizeof(float));
	}
	
	outputParameters.device = OUTPUT_DEVICE;
	outputParameters.channelCount = gNumOutChans;
	outputParameters.sampleFormat = paFloat32;
	outputParameters.suggestedLatency = Pa_GetDeviceInfo( OUTPUT_DEVICE )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;

	err = Pa_OpenStream(
			&stream,		/* newly opened stream */
			NULL,					/* input parameters */
			&outputParameters,		/* output parameters */
			SAMPLE_RATE,			/* sample rate */
			FRAMES_PER_BUFFER,	/* frames per buffer */
			paNoFlag,		/* flags (paNoFlag, paClipOff, paDitherOff,
							   	paPlatformSpecificFlags) */
			process,		/* callback function for processing and
							  	 filling input and output buffers */
			&data );			/* client pointer which is passed to the
							   	callback function */

	if ( err != paNoError )
		goto error;


	/*---------------------------------------------------------------
	  3 - Configure soundplayer DSP
	  ----------------------------------------------------------------*/

	if (gAudioConfigFile == 0)
	{
		char path[255];
		_getcwd(path, 255);
		_snprintf(soundConfName, 	255, "%s\\soundplayer.conf", path);
		gAudioConfigFile = soundConfName;
	}

	DSP.init(gAudioConfigFile, SAMPLE_RATE);


	/*---------------------------------------------------------------
	  4 - Start audio stream
	  ----------------------------------------------------------------*/

	err = Pa_StartStream( stream );
	if( err != paNoError )
		goto error;


	/*---------------------------------------------------------------
	  5 - Run user interface
	  ----------------------------------------------------------------*/

	printf("number of output channels : %d\n",gNumOutChans);
	printf("\nMENU :\n\t'any char' : testing\n\t'q' : quit\n\n");
	while ( (c=getchar())  != 'q' )
	{
		MidiEvPtr e = MidiNewEv(typeNote);
		Chan(e)=0;
		Vel(e)=100;

		switch (c)
		{
			case 'a':
				Pitch(e)=72;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'z':
				Pitch(e)=73;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'e':
				Pitch(e)=74;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'r':
				Pitch(e)=75;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 't':
				Pitch(e)=76;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'y':
				Pitch(e)=77;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'u':
				Pitch(e)=78;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'i':
				Pitch(e)=79;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'o':
				Pitch(e)=80;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
			case 'p':
				Pitch(e)=81;
				MidiSendIm(1|128, e);
				printf("%c sent\n",c);
				break;
		}
	}

	/*---------------------------------------------------------------
	  6 - Close and quit
	  ----------------------------------------------------------------*/

	DSP.conclude();

	err = Pa_StopStream( stream );
	if( err != paNoError )
		goto error;
	err = Pa_CloseStream( stream );
	if( err != paNoError )
		goto error;
	Pa_Terminate();

	for (i=0; i<gNumOutChans; i++)
	{
 		free(data.outCompute[i]);
	}

	printf("GOOD BYE !\n");

	return 0;

	/*---------------------------------------------------------------
	  7 - Errors
	  ----------------------------------------------------------------*/

error:
	Pa_Terminate();
	fprintf( stderr, "An error occured while using the portaudio stream\n" );
	fprintf( stderr, "Error number: %d\n", err );
	fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
	return err;
}
