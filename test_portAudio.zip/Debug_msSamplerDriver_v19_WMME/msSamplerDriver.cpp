/*

  Copyright � Grame 2006

  This library is free software; you can redistribute it and modify it under 
  the terms of the GNU Library General Public License as published by the 
  Free Software Foundation version 2 of the License, or any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public License 
  for more details.

  You should have received a copy of the GNU Library General Public License
  along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Grame Research Laboratory, 9, rue du Garet 69001 Lyon - France
  grame@rd.grame.fr

*/


#include <direct.h>
#include <MidiShare.h>
#include <iostream>

#include "portaudio.h"
#include "sampler.h"

#include "msSamplerDriver.h"
#include "msDriverState.h"


/* ----------------------------------*/
/* constants definitions             */
/* ----------------------------------*/

#define MidiShareDrvRef		127

#define SamplerSlotName "SoundPlayer Sampler"
#define kProfileName  "msSamplerDriver.ini"

#define OUTPUT_DEVICE Pa_GetDefaultOutputDevice()
#define SAMPLE_RATE   (44100)

using namespace std;


/* ----------------------------------*/
/* driver data structure             */
/* ----------------------------------*/

typedef struct {
    PaStream*		stream;

	float			*outCompute[8];
    int				numOutputs;
	int				framesPerBuffer;
} DriverData, * DriverDataPtr;


/* ----------------------------------*/
/* functions declarations            */
/* ----------------------------------*/

DriverData gData;
static DriverDataPtr GetData ()	{return &gData;}
static void AudioSleep(); 
static void AudioStart();


/* ----------------------------------*/
/* FAUST generated code              */
/* ----------------------------------*/

class soundplayer
{
	int			fNumOutputs;
	TSampler 	fSampler;
	int 		fRefNum;

	public:
	soundplayer() : fNumOutputs(8) {}
	virtual ~soundplayer() {}

	virtual int getNumInputs()
	{
		return 0;
	}
	virtual int getNumOutputs() 	
	{
	   	return fNumOutputs;
   	}
	virtual void setNumOutputs(int n) 	
	{
	   fNumOutputs=n;
	}

	/* -------------------------------------------------------------*/
	/* Driver required callbacks                                    */
	/* -------------------------------------------------------------*/
	static void CALLBACK msWakeUp(short r)
	{
		MidiConnect(MidiShareDrvRef, r, true);
		MidiConnect(r, MidiShareDrvRef, true);
		AudioStart();
	}
	static void CALLBACK msSleep(short r)
	{
		AudioSleep();
	}
	/* -------------------------------------------------------------*/

	virtual Boolean init(char* soundConfigFile, int samplingRate)
	{
		//-- 1 - Initialize Sampler

		if (MidiGetNamedAppl(SamplerDriverName) > 0) return true;

		initSampler(&fSampler, soundConfigFile);
		fSampler.fStereoMode = (fNumOutputs==2) ;
		if (fSampler.fStereoMode)
			printf("Mode stereo\n");
		else
			printf("Mode %d pistes\n",fNumOutputs);
		
		//-- 2 - Register Driver
		
		TDriverInfos infos = {SamplerDriverName, kSamplerDriverVersion, 0};
		TDriverOperation op = {msWakeUp, msSleep, 0, 0, 0};
		fRefNum = MidiRegisterDriver(&infos, &op);
		if (fRefNum == MIDIerrSpace) return false;

		//-- 3 - Midi connect & load slot
		
		MidiConnect(0,fRefNum,1);
		MidiSetInfo(fRefNum, &fSampler);

		MidiAddSlot(fRefNum, SamplerSlotName, MidiOutputSlot);
		LoadSlot("Input Slots", GetProfileFullName(kProfileName),SamplerDriverName);

		return true;
	}

	virtual void compute(int len, float** inputs, float** outputs)
	{
		for (int c=0; c<fNumOutputs; c++)
	   	{
			for (int i=0; i<len; i++)
			   	outputs[c][i] = 0.0;
		}
		processMidiEvents(fRefNum);
		mixAllVoices (&fSampler, len, outputs);

		// post processing for volume control
		const float v = fSampler.fMaster;
		for (int d=0; c<fNumOutputs; d++)
	   	{
			float* out = outputs[d];
			for (int i=0; i<len; i++)
			  	out[i] *= v;
		}
	}

	virtual void conclude()
	{	
		short ref = fRefNum;
		fRefNum = 0;
		if (ref > 0) {
			SaveSlot("Input Slots", GetProfileFullName(kProfileName),SamplerDriverName);
			MidiUnregisterDriver(ref);
		}
	}
};

soundplayer	DSP;


/* -----------------------------------------------------------------------------*/
/* PortAudio Callback															*/
/* -----------------------------------------------------------------------------*/

int process (const void *inputBuffer, void *outputBuffer,
		unsigned long framesPerBuffer, const PaStreamCallbackTimeInfo* timeInfo,
		PaStreamCallbackFlags statusFlags, void *userData)
{
	int i, j;
	(void) inputBuffer;	/* Prevent "unused variable" warnings. */ 
	(void) timeInfo; 
	(void) statusFlags;
	
	DriverData *data = (DriverData*)userData;

	DSP.compute(framesPerBuffer, NULL, data->outCompute);

	// uninterlacing loop
	float *out = (float*)outputBuffer;
	for (i=0; i<framesPerBuffer; i++)
	{
		for (j=0; j<data->numOutputs; j++)
		{
			*out++ = data->outCompute[j][i];
		}
	}
	return 0;
}


/* -----------------------------------------------------------------------------*/
/* INI Config 																	*/
/* -----------------------------------------------------------------------------*/

void LoadState()
{
	DriverDataPtr data = GetData();
	data->framesPerBuffer = LoadConfigNum("Configuration",
			"Frames per buffer", GetProfileFullName(kProfileName),1024);
}

/* -----------------------------------------------------------------------------*/
void SaveState()
{
	DriverDataPtr data = GetData();
	SaveConfigNum("Configuration", "Frames per buffer",
			data->framesPerBuffer , GetProfileFullName(kProfileName));
}

/* -----------------------------------------------------------------------------*/
static void AudioStart() 
{
	PaError err;
	DriverDataPtr data = GetData ();
	err = Pa_StartStream(data->stream);
	if( err != paNoError) Pa_Terminate();
}


/* -----------------------------------------------------------------------------*/
/* Audio functions definitions													*/
/* -----------------------------------------------------------------------------*/

Boolean AudioWakeUp() 
{
	//-- 0 - All declarations must be before GOTO 
	
	DriverDataPtr data = GetData ();	// driver data structure
	PaError err;						// port audio error code
	const PaDeviceInfo* devInfo;		// output device infos 
	char* gAudioConfigFile = 0;			// config file path
	char soundConfName[256];			// buffer for config file path 

	PaStreamParameters outputParameters;
	int i;

	//-- 1 - Initialize PortAudio & Open audio stream

	err = Pa_Initialize();
	if ( err != paNoError )
		goto error;
	
	devInfo = Pa_GetDeviceInfo( OUTPUT_DEVICE );
	data->numOutputs = devInfo->maxOutputChannels;
	
	for (i=0; i<data->numOutputs; i++)
	{
 		data->outCompute[i] = (float*) calloc(data->framesPerBuffer,sizeof(float));
	}

	outputParameters.device = OUTPUT_DEVICE;
	outputParameters.channelCount = data->numOutputs;
	outputParameters.sampleFormat = paFloat32;
	outputParameters.suggestedLatency =
		Pa_GetDeviceInfo( OUTPUT_DEVICE )->defaultLowOutputLatency;
	outputParameters.hostApiSpecificStreamInfo = NULL;

	err = Pa_OpenStream(
			&data->stream,			/* newly opened stream */
			NULL,					/* input parameters */
			&outputParameters,		/* output parameters */
			SAMPLE_RATE,			/* sample rate */
			data->framesPerBuffer,	/* frames per buffer */
			paNoFlag,				/* flags */
			process,				/* callback function for processing and
							  	 		filling input and output buffers */
			data );					/* client pointer which is passed to the
							   			callback function */

	if ( err != paNoError )
		goto error;


	//-- 2 - Configure soundplayer DSP

	DSP.setNumOutputs(data->numOutputs);

	if (gAudioConfigFile == 0)
	{
		char path[255];
		_getcwd(path, 255);
		_snprintf(soundConfName, 255, "%s\\soundplayer.conf", path);
		gAudioConfigFile = soundConfName;
	}

	//-- 3 - Initialize Sampler Midi and soundplayer DSP
	
	if ( !DSP.init(gAudioConfigFile, SAMPLE_RATE) )
	{
        printf("Sampler Midi Init failed\n");
		return false;
	}
    
	return true;

	//-- 4 - Errors

error:
	Pa_Terminate();
	fprintf( stderr, "An error occured while using the portaudio stream\n" );
	fprintf( stderr, "Error number: %d\n", err );
	fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
	return false;
}

/* -----------------------------------------------------------------------------*/
static void AudioSleep() 
{
	//-- 0 - All declarations must be before GOTO 
	
	int i;
	DriverDataPtr data = GetData ();
	PaError err;

	//-- 1 - Close Sampler Midi and soundplayer DSP
	
	DSP.conclude();

	//-- 2 - Save config
	
	SaveState();

	//-- 3 - Stop and close audio stream & Terminate PortAudio
	
	err = Pa_StopStream( data->stream );
	if( err != paNoError )
		goto error;
	err = Pa_CloseStream( data->stream );
	if( err != paNoError )
		goto error;
	Pa_Terminate();

	for (i=0; i<data->numOutputs; i++)
	{
 		free(data->outCompute[i]);
	}

	printf("GOOD BYE !\n");

	//-- 4 - Errors
	
error:
	Pa_Terminate();
	fprintf( stderr, "An error occured while using the portaudio stream\n" );
	fprintf( stderr, "Error number: %d\n", err );
	fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );

}  

/* -----------------------------------------------------------------------------*/
Boolean Start() 
{
    LoadState();
    if (!AudioWakeUp()) {
        printf("Sampler AudioWakeUp failed\n");
        return false;
    }
	return true;
	
}

/* -----------------------------------------------------------------------------*/
void Stop()
{
	DSP.conclude();
	SaveState();
}

/* -----------------------------------------------------------------------------*/
BOOL WINAPI DllEntryPoint(HINSTANCE  hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
	if ( MidiGetVersion() < 184) return FALSE;
	switch (fdwReason) {
		case DLL_PROCESS_ATTACH:
			Start();
			break;
		case DLL_PROCESS_DETACH:
			Stop();
			break;
	 }
    return TRUE;
}

// intended only to avoid link error
main() {return 0;}
