/*

  Copyright � Grame 1999-2005

  This library is free software; you can redistribute it and modify it under 
  the terms of the GNU Library General Public License as published by the 
  Free Software Foundation version 2 of the License, or any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public 
  License for more details.

  You should have received a copy of the GNU Library General Public License
  along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Grame Research Laboratory, 9, rue du Garet 69001 Lyon - France
  research@grame.fr

*/


#ifndef __msAtomicIntel__
#define __msAtomicIntel__

#ifdef __SMP__
#	define LOCK "lock ; "
#else
#	define LOCK ""
#endif

//----------------------------------------------------------------
// CAS functions
//----------------------------------------------------------------
static inline char CAS (volatile void * addr, volatile void * value, void * newvalue) 
{
	register char ret;
	__asm__ __volatile__ (
		"# CAS \n\t"
		LOCK "cmpxchg %2, (%1) \n\t"
		"sete %0               \n\t"
		:"=a" (ret)
		:"c" (addr), "d" (newvalue), "a" (value)
	);
	return ret;
}

static inline char CAS2 (volatile void * addr, volatile void * v1, volatile long v2, void * n1, long n2) 
{
	register char ret;
	__asm__ __volatile__ (
		"# CAS2 \n\t"
		LOCK "cmpxchg8b (%1) \n\t"
		"sete %0               \n\t"
		:"=a" (ret)
		:"D" (addr), "d" (v2), "a" (v1), "b" (n1), "c" (n2)
	);
	return ret;
}

#endif
