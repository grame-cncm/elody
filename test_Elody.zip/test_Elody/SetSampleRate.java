import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.File;
import java.lang.Thread;
import java.lang.InterruptedException;

import grame.midishare.*;
import grame.midishare.tools.*;

class SetSampleRate 
{
	private native static int GetHostAPICount();
	private native static PaHostApiInfo[] GetHostAPIInfos(int apiNumber);
	private native static PaDeviceInfo[] GetDeviceInfos(int apiIndex, int devNumber);
	private native static boolean AudioWakeUp(int sampleRate, String configFile, int apiIndex, int devIndex);

	public static void main(String args[])
	{
		int appRefNum = Midi.Open("Client Sampler");
		if (appRefNum <= 0)
		{
			System.out.println("ERROR: MidiOpen fail");
		}
		Midi.Connect (appRefNum, 0, 1);
		int sampleRate, api, dev;
		String configFile;
		if (prompt("Do you want to use default parameters (Y/N)?").equals("Y"))
		{
			sampleRate=44100;
			configFile="soundplayer.conf";
			api=0;
			dev=2;
		}
		else
		{
			int apiNumber = GetHostAPICount();
			PaHostApiInfo apiList[] = new PaHostApiInfo[apiNumber];
			apiList=GetHostAPIInfos(apiNumber);
			for (int i=0; i<apiNumber; i++)
			{
				if (apiList[i]!=null)
					apiList[i].printAll(i);
			}
			System.out.println();
			api = Integer.parseInt(prompt("API number?"));
			while ((api<0)||(api>=apiNumber))
			{
				System.out.println("ERROR: Wrong API number");
				api = Integer.parseInt(prompt("API number?"));
			}
			System.out.println("You chose: "+apiList[api].getName());
			int devNumber = apiList[api].getDeviceCount();
			dev=-1;
			if (devNumber>0)
			{
				PaDeviceInfo devList[] = new PaDeviceInfo[devNumber];
				devList=GetDeviceInfos(api, devNumber);
				for (int i=0; i<devNumber; i++)
				{
					if (devList[i]!=null)
						devList[i].printAll(i);
				}
				System.out.println();
				dev = Integer.parseInt(prompt("Device number?"));
				while ((dev<0)||(dev>=devNumber))
				{
					System.out.println("ERROR: Wrong Device number");
					dev = Integer.parseInt(prompt("Device number?"));
				}
				System.out.println("You chose : "+devList[dev].getName());
			}
			else
			{
				System.out.println("WARNING: There is no device for this API");
			}

			sampleRate = Integer.parseInt(prompt("SampleRate (Hz)?"));
			configFile = prompt("INI Config File Name?");
			boolean exists = (new File(configFile)).exists();
			while (!exists)
			{
				System.out.println("ERROR: This config file doesn't exist");
				configFile = prompt("INI Config File Name?");
				exists = (new File(configFile)).exists();	
			}
		}
		if (!AudioWakeUp(sampleRate, configFile, api, dev)) 
		{
			System.out.println("ERROR: Sampler AudioWakeUp failed");
		}

		Midi.SendIm(appRefNum, MidiEvent.Note(72, 100, 1000, 0, 0));

		try { Thread.sleep(5000); }
		catch (InterruptedException e) { System.out.println("Erreur du timer"); }
		Midi.Close(appRefNum);

	}
	public static String prompt(String prompt)
	{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println (prompt);
		System.out.print ("> ");
		String chaine="";
		try { chaine = in.readLine(); }
		catch (IOException e) {	System.out.println("Erreur de lecture"); };
		return chaine;
	}
	static
	{
		System.loadLibrary("msSamplerDriver");
		System.loadLibrary("Player32");
		System.loadLibrary("JMidi");
		System.loadLibrary("JPlayer");
	}
}
